﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace KVBook
{
    class Town
    {
        public string Name = "";
        public int NumberInhabitant = 0;
        public double Sguare = 0;
    }
    static class Tonws
    {

        static public int Size;
        static public List<Town> TownList = new List<Town>();
        static public void ADD()
        {
            Console.Write("Размер массива = ");
            Size = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < Size; i++)
            {
                Town TempTown = new Town();
                Console.Write("Название города №" + i + " = ");
                TempTown.Name = Console.ReadLine().ToString();

                Console.Write("Количество жителей №" + i + " = ");
                TempTown.NumberInhabitant = Convert.ToInt32(Console.ReadLine());

                Console.Write("Площадь занимаемой поверхности №" + i + " = ");
                TempTown.Sguare = Convert.ToDouble(Console.ReadLine());

                TownList.Add(TempTown);
            }
        }
        static public void Sort()
        {
            TownList.OrderBy(r => r.NumberInhabitant).ThenBy(r => r.Sguare).ToArray();
        }
        static public void SaveInFile()
        {
            using (StreamWriter sw = new StreamWriter("TownsList.txt"))
            {
                foreach (Town T in TownList)
                    sw.WriteLine(T.Name + ", " + T.NumberInhabitant + ", " + T.Sguare.ToString());
            }
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Tonws.ADD();
            Tonws.Sort();
            Tonws.SaveInFile();

        }
    }
}